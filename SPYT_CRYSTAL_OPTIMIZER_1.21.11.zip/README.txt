SPYT CRYSTAL OPTIMIZER
Minecraft Java Edition 1.21.11

Install: move this ZIP into .minecraft/resourcepacks, then enable it in Options > Resource Packs.
Includes custom End Crystal and beam textures. This is a visual resource pack; it does not change game mechanics or guarantee FPS gains.
