SPYT PVP PACK
Minecraft Java Edition 1.21.11

Included:
- Orange main-menu panorama
- Green menu button sprites
- Green amethyst cluster/bud/shard textures
- Smaller GUI display scale for a selected set of common PvP/inventory items

Install:
1. Keep this ZIP file compressed.
2. Open Minecraft -> Options -> Resource Packs -> Open Pack Folder.
3. Move SPYT_PVP_PACK.zip into that folder.
4. Return to Minecraft and enable the pack.

Note:
Small-item GUI scaling is applied to the item models included in this pack, not every Minecraft item.
Some inventory/screen backgrounds are controlled by separate GUI textures and are not all recolored in this starter build.

- Main-menu edition subtitle changed to SPYT EDITION.

Update: Enlarged SPYT EDITION title label and refreshed pack icon/profile artwork.

Update: SPYT EDITION lettering is now slanted/italic pixel style.

Update: SPYT EDITION title lettering corrected to straight, upright, centered pixel text.
Modrinth page: https://modrinth.com/ (a vanilla Java resource pack cannot add a clickable in-game link/button).

Update: Branded the multiplayer terrain-loading message as 'SPYT EDITION • Arazi yükleniyor...' in Turkish and 'SPYT EDITION • Loading terrain...' in English.
Note: A vanilla resource pack can replace the existing loading text, but cannot add a separate extra line above it or redesign the loading screen layout; that needs a client-side mod.

Update: Refreshed the pack icon/profile. Removed all custom item model scaling overrides so items use their normal vanilla size again. Added subtle green-accent sword textures and a green mace texture.
