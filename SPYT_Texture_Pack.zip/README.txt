SPYT TEXTURE PACK — Java Edition

Theme:
- SPYT branding
- Green inventory panel accent
- Blue daytime / navy evening concept

Compatibility note:
Vanilla Java resource packs cannot show custom floating text in the sky that changes color by time of day. Dynamic custom skies and floating SPYT text generally require compatible mod/shader or OptiFine-style custom sky support. This starter pack includes a branded pack icon and a green inventory panel texture at a legacy GUI path; modern 1.21.x GUI sprite layouts may need version-specific files.

Install:
1. Place SPYT_Texture_Pack.zip in .minecraft/resourcepacks
2. Open Minecraft → Options → Resource Packs
3. Select SPYT and apply.

The pack format is set to 75 as a best-effort 1.21.x value; if Minecraft flags it as incompatible, the exact 1.21.11 format may differ.
